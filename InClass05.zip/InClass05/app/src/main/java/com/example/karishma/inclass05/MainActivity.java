package com.example.karishma.inclass05;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    ImageButton prev;
    ImageButton next;

    ArrayList<String> urls = new ArrayList<>();
    public static ImageView urlimageview;
    public static ProgressDialog pd;
    public int counter=0;
    String baseUrl = "http://dev.theappsdr.com/apis/photos/index.php?keyword=";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        urlimageview= (ImageView) findViewById(R.id.imageView);
        pd=new ProgressDialog(MainActivity.this);

        final TextView searchKey = (TextView) findViewById(R.id.searchKeyword);
        Button go = (Button) findViewById(R.id.go) ;
        prev = (ImageButton) findViewById(R.id.prevBtn);
        next = (ImageButton) findViewById(R.id.imageButton2);
        prev.setEnabled(false);
        next.setEnabled(false);
        searchKey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String[] keyword = {"UNCC","Android","Winter","Aurora","Wonders"};
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Make your selection");
                builder.setItems(keyword, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        // Do something with the selection
                        searchKey.setText(keyword[item]);
                        Log.d("img",keyword[item]);
                        urls.clear();
                        if(isConnectedcheck()) {
                            new GetPhotoIds().execute(baseUrl + keyword[item].toLowerCase(), keyword[item]);
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this,"No Network",Toast.LENGTH_LONG).show();
                        }
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });

        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(urls.size()>1) {
                    prev.setEnabled(true);
                    next.setEnabled(true);
                }

                    if (isConnectedcheck() && urls.size() != 0)
                        new Imageload().execute(urls.get(0));

                    else
                        Toast.makeText(MainActivity.this, "No Network or No Images found", Toast.LENGTH_LONG).show();
                    //pass url and keyword

            }
        });

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(counter==0)
                {
                    counter=urls.size()-1;
                }
                else
                {
                    counter--;
                }
                if(isConnectedcheck())
                    new Imageload().execute(urls.get(counter));
                else
                    Toast.makeText(MainActivity.this,"No Network",Toast.LENGTH_LONG).show();
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(counter==urls.size()-1)
                {
                    counter=0;
                }
                else
                {
                    counter++;
                }
                if(isConnectedcheck())
                    new Imageload().execute(urls.get(counter));
                else
                    Toast.makeText(MainActivity.this,"No Network",Toast.LENGTH_LONG).show();
            }
        });
    }
    public class GetPhotoIds extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... strings) {
            StringBuilder sb = new StringBuilder();
            String key = null;

            try {
                URL url = new URL(strings[0]);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                BufferedReader rd = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String line = "";
                while((line=rd.readLine())!=null){
                    sb.append(line);


                }
                    if(sb.length()==0)
                        Toast.makeText(MainActivity.this,"No Images Found",Toast.LENGTH_LONG).show();
                else {
                        key = sb.substring(strings[1].length() + 1, sb.length());
                        Log.d("img", key);
                    }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return key;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
            ProgressDialog pd = new ProgressDialog(MainActivity.this);
            pd.setMessage("Loading Dictionary....");
            pd.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            String[] imgUrl = s.split(";");
            for (String img:imgUrl) {
                urls.add(img);
            }
            Log.d("img",urls.toString());
        }
    }

    public boolean isConnectedcheck()
    {
        ConnectivityManager cm= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info=cm.getActiveNetworkInfo();
        if(info!=null&&info.isConnected())
        {
            return true;
        }
   else
        {
            return false;
        }
    }

}
