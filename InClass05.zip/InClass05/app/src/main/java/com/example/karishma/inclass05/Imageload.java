package com.example.karishma.inclass05;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by karishma on 9/19/2016.
 */
public class Imageload extends AsyncTask<String,Void,Bitmap>{

    @Override
    protected Bitmap doInBackground(String... arrayLists) {
        String first=null;
        Bitmap image=null;
       // first=arrayLists[0].get(0);
        InputStream in=null;
        URL url = null;
        try {
            url = new URL(arrayLists[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            in=con.getInputStream();
            image= BitmapFactory.decodeStream(in);
            return image;

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
              return image;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        ImageView iv=MainActivity.urlimageview;
        iv.setImageBitmap(bitmap);
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
        ProgressDialog pd = MainActivity.pd;
        pd.setMessage("Loading Photo...");
        pd.show();
    }
}
