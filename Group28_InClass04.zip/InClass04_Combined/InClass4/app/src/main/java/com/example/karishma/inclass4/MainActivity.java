package com.example.karishma.inclass4;

import android.app.Activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;


public class MainActivity extends Activity {

    SeekBar count, length;
    TextView countValue, lengthValue;

    Handler handler ;
    String[] passwordsFromRun;
    ThreadPoolExecutor pool;
    ProgressDialog progressDialog1;
    ProgressDialog progressDialog2;
    String[] finalStrings;
    TextView pass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pass=(TextView)findViewById(R.id.pass);
        count = (SeekBar)findViewById(R.id.seekBarPwdCount);
        length = (SeekBar) findViewById(R.id.seekBarPwdLength);

        count.setMax(10);
        length.setMax(15);
        countValue =(TextView) findViewById(R.id.value1);
        lengthValue =(TextView) findViewById(R.id.value2);

        count.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                countValue.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        length.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                lengthValue.setText(String.valueOf(progress+8));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        
       Button threadClick_Btn = (Button) findViewById(R.id.pwdThreadbtn);
        threadClick_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog1 = new ProgressDialog(MainActivity.this);
                progressDialog1.setMessage("Generating Passwords...");
                progressDialog1.setMax(count.getProgress());
                progressDialog1.setCancelable(false);
                progressDialog1.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);

                pool = (ThreadPoolExecutor) Executors.newFixedThreadPool(2);
                handler = new Handler(new Handler.Callback() {
                    @Override
                    public boolean handleMessage(Message msg) {
                        switch (msg.what) {
                            case ThreadWork.STATUS_START:
                                progressDialog1.show();
                                break;
                            case ThreadWork.STATUS_STEP:
                                progressDialog1.setProgress((int)msg.obj);
                                break;
                            case ThreadWork.STATUS_END:
                                progressDialog1.dismiss();
                                passwordsFromRun = new String[msg.getData().getStringArray("PASSWORD").length];
                                passwordsFromRun = msg.getData().getStringArray("PASSWORD");
                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                builder.setTitle("Make your selection");
                                builder.setItems(passwordsFromRun, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int item) {
                                        // Do something with the selection
                                        String passwordSelected = passwordsFromRun[item];
                                        TextView pass = (TextView) findViewById(R.id.pass);
                                        pass.setText(passwordSelected);
                                    }
                                });
                                AlertDialog alert = builder.create();
                                alert.show();

                                break;
                        }
                        return false;
                    }
                });
                pool = (ThreadPoolExecutor) Executors.newFixedThreadPool(2);
                pool.execute(new ThreadWork());


            }

        });
        findViewById(R.id.pwdAsyncbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SeekBar sb1 =(SeekBar) findViewById(R.id.seekBarPwdCount);
                SeekBar sb2 = (SeekBar) findViewById(R.id.seekBarPwdLength);

                int countValue = sb1.getProgress();
                int lengthValue = sb2.getProgress();
                new DoWork().execute(countValue, lengthValue);
            }
        });


    }

    class ThreadWork implements Runnable{

        static final int STATUS_START = 0x00;
        static final int STATUS_STEP = 0x01;
        static final int STATUS_END = 0x02;

        @Override
        public void run() {
            Message msg = new Message();
            Random rand = new Random();
            int randomInt = 0;
            msg.what = STATUS_START;
            handler.sendMessage(msg);
            String[] passwords = new String[count.getProgress()];

            for (int i = 0; i < count.getProgress(); i++) {
                msg = new Message();
                msg.what = STATUS_STEP;
                passwords[i] = Util.getPassword(length.getProgress()+8);
                msg.obj = i+1;
                handler.sendMessage(msg);
            }

            msg = new Message();
            msg.what = STATUS_END;
            Bundle passwordData = new Bundle();
            passwordData.putStringArray("PASSWORD", passwords);
            msg.setData(passwordData);
            handler.sendMessage(msg);
        }
    }


    class DoWork extends AsyncTask<Integer, Integer, String[]> {

        @Override
        protected String[] doInBackground(Integer... params) {
            String result[]= new String[params[0]];

            for(int i=0; i<params[0]; i++){
                publishProgress((100*i)/params[0]);
                result[i] = Util.getPassword(params[1]+8);
                Log.d("demo",result[i]);

            }
            Log.d("demo",String.valueOf(result.length));
            return result;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog2 = new ProgressDialog(MainActivity.this);
            progressDialog2.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog2.setMax(100);
            progressDialog2.setCancelable(false);
            progressDialog2.setMessage("Generating Passwords");
            progressDialog2.show();
        }

        @Override
        protected void onPostExecute(final String[] strings) {
            super.onPostExecute(strings);
            progressDialog2.dismiss();
            android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Passwords");
            builder.setItems(strings, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finalStrings=strings;
                    pass.setText(finalStrings[which]);
                }
            });
            android.support.v7.app.AlertDialog alert = builder.create();
            alert.show();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog2.setProgress(values[0]);
        }
    }
}

