package com.example.karishma.baccalculator;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    double calculated_BAC;
    SeekBar sb;
    TextView value;
    ProgressBar result;
    TextView statusValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sb = (SeekBar) findViewById(R.id.seekBar);
        value = (TextView) findViewById(R.id.value);
        result = (ProgressBar) findViewById(R.id.progressBar);
        statusValue = (TextView) findViewById(R.id.statusValue);

        sb.setProgress(5);
        sb.setMax(25);
        result.setMax(25);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                value.setText(String.valueOf(progress) + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        final Button saveBtn = (Button) findViewById(R.id.saveBtn);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText et1 = (EditText) findViewById(R.id.enterWeight);
                Switch gender = (Switch) findViewById(R.id.gender);
                if (et1.getText().toString().equals("") && gender.equals(null)) {
                    et1.setError("Enter Valid Weight and Gender Value");
                }
            }
        });

        final Button addDrink_btn = (Button) findViewById(R.id.addDrinkBtn);

        addDrink_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioGroup rg = (RadioGroup) findViewById(R.id.radioGroup);

                EditText et1 = (EditText) findViewById(R.id.enterWeight);
                String weight = et1.getText().toString();
                Double weight_value = Double.parseDouble(weight);

                SeekBar alcohol = (SeekBar) findViewById(R.id.seekBar);
                double alcoholValue = alcohol.getProgress();
                Log.d("alcohol",alcoholValue+"");

                Switch gender = (Switch) findViewById(R.id.gender);

                if (gender.isChecked()) { //Male
                    if (rg.getCheckedRadioButtonId() == R.id.oneOZ) { //1 oz
                        calculated_BAC = ((1 * (alcoholValue / 100)) / weight_value * (0.68));
                    } else if (rg.getCheckedRadioButtonId() == R.id.fiveOZ) {
                        calculated_BAC = ((5 * (alcoholValue / 100)) / weight_value * (0.68));
                    } else if (rg.getCheckedRadioButtonId() == R.id.twelveOZ) {
                        calculated_BAC = ((12 * (alcoholValue / 100)) / weight_value * (0.68));
                    }
                } else { //Female
                    if (rg.getCheckedRadioButtonId() == R.id.oneOZ) { //1 oz
                        calculated_BAC = ((1 * (alcoholValue / 100)) / weight_value * (0.55));
                    } else if (rg.getCheckedRadioButtonId() == R.id.fiveOZ) {
                        calculated_BAC = ((5 * (alcoholValue / 100)) / weight_value * (0.55));
                    } else if (rg.getCheckedRadioButtonId() == R.id.twelveOZ) {
                        calculated_BAC = ((12 * (alcoholValue / 100)) / weight_value * (0.55));
                    }
                }

                TextView bac = (TextView) findViewById(R.id.bacLevelText);
                bac.setText(calculated_BAC + "");
                result.setProgress(new Double(calculated_BAC*100).intValue());

                if(calculated_BAC <= 0.08)
                {
                    statusValue.setText("You're safe");
                    statusValue.setBackgroundColor(Color.GREEN);
                }
                else if(calculated_BAC > 0.08 && calculated_BAC < 0.20)
                {
                    statusValue.setText("Be Careful");
                    statusValue.setBackgroundColor(Color.YELLOW);
                }
                else if(calculated_BAC >= 0.20 && calculated_BAC < 0.25)
                {
                    statusValue.setText("Over the Limit");
                    statusValue.setBackgroundColor(Color.RED);
                }
                else if(calculated_BAC >= 0.25)
                {
                    saveBtn.setEnabled(false);
                    addDrink_btn.setEnabled(false);
                    Toast.makeText(getApplicationContext(), "No more drinks for you", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button reset_btn = (Button) findViewById(R.id.resetBtn);

        reset_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText et1 = (EditText) findViewById(R.id.enterWeight);
                TextView bac = (TextView) findViewById(R.id.bacLevelText);
                SeekBar alcohol = (SeekBar) findViewById(R.id.seekBar);
                RadioButton rb = (RadioButton) findViewById(R.id.oneOZ);
                Switch gender = (Switch) findViewById(R.id.gender);

                alcohol.setProgress(5);
                et1.setText("");
                bac.setText("");
                rb.setChecked(true);
                gender.setChecked(false);
            }
        });
    }
}
