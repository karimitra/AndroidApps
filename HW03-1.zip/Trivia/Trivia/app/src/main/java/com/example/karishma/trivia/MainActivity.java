package com.example.karishma.trivia;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    public static ProgressDialog pd;
    public static ImageView image;
    final static String questions_list = "Questions_List";
    static ArrayList<Questions> questions;
    TextView triviaReady;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image = (ImageView) findViewById(R.id.imageView);
        pd=new ProgressDialog(MainActivity.this);
        String uri="@drawable/trivia";
        int imageResource= getResources().getIdentifier(uri, null, getPackageName());
        triviaReady=(TextView)findViewById(R.id.textViewTriviaReady);
        //new ImageLoad().execute()

        new GetQuestions().execute("http://dev.theappsdr.com/apis/trivia_json/index.php");
        Drawable res=getResources().getDrawable(imageResource);
        image.setImageDrawable(res);
        triviaReady.setText("Trivia Ready");


        findViewById(R.id.startBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    questions = new GetQuestions().execute("http://dev.theappsdr.com/apis/trivia_json/index.php").get();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }

                Intent intent = new Intent(MainActivity.this, Trivia.class);
                intent.putParcelableArrayListExtra(questions_list,questions);
                Log.d("demo", "rimple "+questions);
                startActivity(intent);


            }
        });

        findViewById(R.id.exitBtnMain).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });




    }
}
