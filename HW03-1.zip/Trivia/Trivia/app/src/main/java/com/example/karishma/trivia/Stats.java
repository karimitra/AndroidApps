package com.example.karishma.trivia;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Stats extends AppCompatActivity {
    int rightAnswers;
    ProgressBar stats;
    TextView progressAmt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        progressAmt=(TextView)findViewById(R.id.progressAmt);
        stats=(ProgressBar)findViewById(R.id.progressBar);
        if(getIntent().getExtras() != null)
        {
            rightAnswers = getIntent().getIntExtra(Trivia.rightanswers,0);
        }
        stats.setMax(100);
        stats.setProgress((rightAnswers*100)/16);
        progressAmt.setText((rightAnswers*100)/16 + "%");
        Log.d("demo", "progress");


        findViewById(R.id.TryAgainButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Stats.this, Trivia.class);
                Trivia.first=0;
                startActivity(intent);
            }
        });

        findViewById(R.id.quitButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Stats.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}
