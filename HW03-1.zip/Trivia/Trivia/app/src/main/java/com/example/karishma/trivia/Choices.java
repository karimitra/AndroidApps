package com.example.karishma.trivia;

/**
 * Created by karishma on 9/22/2016.
 */
public class Choices {
}
