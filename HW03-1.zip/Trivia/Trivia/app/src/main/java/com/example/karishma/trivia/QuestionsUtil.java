package com.example.karishma.trivia;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by karishma on 9/22/2016.
 */
public class QuestionsUtil {

    public static class QuestionsJSONParser{
        static ArrayList<Questions> parseQuestions(String in) throws JSONException {
            ArrayList<Questions> questionsList = new ArrayList<>();
            ArrayList<String> choicesList;
            JSONObject root = new JSONObject(in);
            JSONArray questionsJSONArray = root.getJSONArray("questions");

            for(int i =0;i<questionsJSONArray.length();i++){
                JSONObject questionsJSONObject = questionsJSONArray.getJSONObject(i);
                Questions questions = new Questions();
                questions.setId(questionsJSONObject.getString("id"));
                questions.setText(questionsJSONObject.getString("text"));

                if(questionsJSONObject.isNull("image")) {
                    questions.setImage(null);
                }
                else
                {
                    questions.setImage(questionsJSONObject.getString("image"));
                }
                JSONObject choices=questionsJSONObject.getJSONObject("choices");
                JSONArray choicesArray = choices.getJSONArray("choice");
                choicesList = new ArrayList<>();

                for(int k =0;k<choicesArray.length();k++){
                    choicesList.add(choicesArray.get(k).toString());
                }

                questions.setChoices(choicesList);

                questions.setAnswer(choices.getString("answer"));

                questionsList.add(questions);



            }


            return questionsList;
        }
    }
}