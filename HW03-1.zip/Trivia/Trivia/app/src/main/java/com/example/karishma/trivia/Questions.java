package com.example.karishma.trivia;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by karishma on 9/22/2016.
 */
public class Questions implements Parcelable{

    String id,text,image,answer;
    ArrayList<String> choices;

    public Questions() {
    }

    public Questions(String id, String text, String image, String answer,  ArrayList<String> choices) {
        this.id = id;
        this.text = text;
        this.image = image;
        this.answer = answer;
        this.choices = choices;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public  ArrayList<String> getChoices() {
        return choices;
    }

    public void setChoices( ArrayList<String> choices) {
        this.choices = choices;
    }


    public static final Creator<Questions> CREATOR = new Creator<Questions>() {
        @Override
        public Questions createFromParcel(Parcel in) {
            return new Questions(in);
        }

        @Override
        public Questions[] newArray(int size) {
            return new Questions[size];
        }
    };
    @Override
    public String toString() {
        return "Questions{" +
                "id='" + id + '\'' +
                ", text='" + text + '\'' +
                ", image='" + image + '\'' +
                ", answer='" + answer + '\'' +
                ", choices=" + choices +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(text);
        dest.writeString(image);
        dest.writeString(answer);
        dest.writeList(choices);

    }

    protected Questions(Parcel in) {
        id = in.readString();
        text = in.readString();
        image = in.readString();
        answer = in.readString();
        choices=new ArrayList<>();
        in.readList(choices,null);
    }
}
