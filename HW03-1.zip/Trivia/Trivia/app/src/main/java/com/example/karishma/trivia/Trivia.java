package com.example.karishma.trivia;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class Trivia extends AppCompatActivity {

    final static String rightanswers = "rightanswers";
    public static ImageView urlimageview;
    public static ProgressDialog pd;
    ArrayList<Questions> questionsArrayList = new ArrayList<>();
    String answerText;
    int count;
    RadioGroup rg;
    TextView quest;
    ArrayList<String> imgUrls = new ArrayList<>();
    TextView timer;
    static int first = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia);

        questionsArrayList = getIntent().getParcelableArrayListExtra(MainActivity.questions_list);

     //   Log.d("demo-Trivia","TRIVIA  " + questionsArrayList.get(0));
        //questionsArrayList=MainActivity.questList;

        urlimageview= (ImageView) findViewById(R.id.imageView3);
        //pd=new ProgressDialog(Trivia.this);

        count = 0;

        timer = (TextView) findViewById(R.id.timeLeft);

        for (int i=0;i<questionsArrayList.size();i++){
            imgUrls.add(questionsArrayList.get(i).getImage());
        }
        Log.d("img",""+imgUrls);

        new ImageLoad().execute(imgUrls.get(first));

        TextView questNum = (TextView) findViewById(R.id.questionNum);
        questNum.setText("Q" + (Integer.parseInt(questionsArrayList.get(first).getId())+1));

        int answer = Integer.parseInt(questionsArrayList.get(first).getAnswer());
        answerText = questionsArrayList.get(first).getChoices().get(answer-1);

        rg = (RadioGroup) findViewById(R.id.rg);
        RadioButton r1 = (RadioButton) findViewById(R.id.radioButton);
        RadioButton r2 = (RadioButton) findViewById(R.id.radioButton2);
        RadioButton r3 = (RadioButton) findViewById(R.id.radioButton3);
        RadioButton r4 = (RadioButton) findViewById(R.id.radioButton4);
        RadioButton r5 = (RadioButton) findViewById(R.id.radioButton5);
        RadioButton r6 = (RadioButton) findViewById(R.id.radioButton6);
        RadioButton r7 = (RadioButton) findViewById(R.id.radioButton7);
        RadioButton r8 = (RadioButton) findViewById(R.id.radioButton8);

        int choiceSize = questionsArrayList.get(first).getChoices().size();

        r1.setText(questionsArrayList.get(first).getChoices().get(0));
        r2.setText(questionsArrayList.get(first).getChoices().get(1));
        r3.setText(questionsArrayList.get(first).getChoices().get(2));
        r4.setVisibility(View.INVISIBLE);
        r5.setVisibility(View.INVISIBLE);
        r6.setVisibility(View.INVISIBLE);
        r7.setVisibility(View.INVISIBLE);
        r8.setVisibility(View.INVISIBLE);

        if(choiceSize == 4)
        {
            r4.setVisibility(View.VISIBLE);
            r4.setText(questionsArrayList.get(first).getChoices().get(3));
        }
        else if(choiceSize == 5)
        {
            r4.setVisibility(View.VISIBLE);
            r5.setVisibility(View.VISIBLE);
            r4.setText(questionsArrayList.get(first).getChoices().get(3));
            r5.setText(questionsArrayList.get(first).getChoices().get(4));
        }
        else if(choiceSize == 6)
        {
            r4.setVisibility(View.VISIBLE);
            r5.setVisibility(View.VISIBLE);
            r6.setVisibility(View.VISIBLE);
            r4.setText(questionsArrayList.get(first).getChoices().get(3));
            r5.setText(questionsArrayList.get(first).getChoices().get(4));
            r6.setText(questionsArrayList.get(first).getChoices().get(5));
        }
        else if (choiceSize == 7)
        {
            r4.setVisibility(View.VISIBLE);
            r5.setVisibility(View.VISIBLE);
            r6.setVisibility(View.VISIBLE);
            r7.setVisibility(View.VISIBLE);
            r4.setText(questionsArrayList.get(first).getChoices().get(3));
            r5.setText(questionsArrayList.get(first).getChoices().get(4));
            r6.setText(questionsArrayList.get(first).getChoices().get(5));
            r7.setText(questionsArrayList.get(first).getChoices().get(6));
        }
        else if (choiceSize == 8)
        {
            r4.setVisibility(View.VISIBLE);
            r5.setVisibility(View.VISIBLE);
            r6.setVisibility(View.VISIBLE);
            r7.setVisibility(View.VISIBLE);
            r8.setVisibility(View.VISIBLE);
            r4.setText(questionsArrayList.get(first).getChoices().get(3));
            r5.setText(questionsArrayList.get(first).getChoices().get(4));
            r6.setText(questionsArrayList.get(first).getChoices().get(5));
            r7.setText(questionsArrayList.get(first).getChoices().get(6));
            r8.setText(questionsArrayList.get(first).getChoices().get(7));
        }


        quest = (TextView) findViewById(R.id.questText);
        quest.setText(questionsArrayList.get(first).getText());

        findViewById(R.id.nextBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (first < questionsArrayList.size()-1) {
                    first++;

                    Log.d("first", "" + first);
                    String value = ((RadioButton) findViewById(rg.getCheckedRadioButtonId())).getText().toString();
                    if (answerText.equals(value)) {
                        count++;
                    }

                    Log.d("Test", "Test");
                    new ImageLoad().execute(imgUrls.get(first));

                    TextView questNum = (TextView) findViewById(R.id.questionNum);
                    questNum.setText("Q" + (Integer.parseInt(questionsArrayList.get(first).getId())+1));

                    int answer = Integer.parseInt(questionsArrayList.get(first).getAnswer());
                    answerText = questionsArrayList.get(first).getChoices().get(answer - 1);

                    rg = (RadioGroup) findViewById(R.id.rg);
                    RadioButton r1 = (RadioButton) findViewById(R.id.radioButton);
                    RadioButton r2 = (RadioButton) findViewById(R.id.radioButton2);
                    RadioButton r3 = (RadioButton) findViewById(R.id.radioButton3);
                    RadioButton r4 = (RadioButton) findViewById(R.id.radioButton4);
                    RadioButton r5 = (RadioButton) findViewById(R.id.radioButton5);
                    RadioButton r6 = (RadioButton) findViewById(R.id.radioButton6);
                    RadioButton r7 = (RadioButton) findViewById(R.id.radioButton7);
                    RadioButton r8 = (RadioButton) findViewById(R.id.radioButton8);

                    int choiceSize = questionsArrayList.get(first).getChoices().size();

                    r1.setText(questionsArrayList.get(first).getChoices().get(0));
                    r2.setText(questionsArrayList.get(first).getChoices().get(1));
                    r3.setText(questionsArrayList.get(first).getChoices().get(2));
                    r4.setVisibility(View.INVISIBLE);
                    r5.setVisibility(View.INVISIBLE);
                    r6.setVisibility(View.INVISIBLE);
                    r7.setVisibility(View.INVISIBLE);
                    r8.setVisibility(View.INVISIBLE);

                    if (choiceSize == 4) {
                        r4.setVisibility(View.VISIBLE);
                        r4.setText(questionsArrayList.get(first).getChoices().get(3));
                    } else if (choiceSize == 5) {
                        r4.setVisibility(View.VISIBLE);
                        r5.setVisibility(View.VISIBLE);
                        r4.setText(questionsArrayList.get(first).getChoices().get(3));
                        r5.setText(questionsArrayList.get(first).getChoices().get(4));
                    } else if (choiceSize == 6) {
                        r4.setVisibility(View.VISIBLE);
                        r5.setVisibility(View.VISIBLE);
                        r6.setVisibility(View.VISIBLE);
                        r4.setText(questionsArrayList.get(first).getChoices().get(3));
                        r5.setText(questionsArrayList.get(first).getChoices().get(4));
                        r6.setText(questionsArrayList.get(first).getChoices().get(5));
                    } else if (choiceSize == 7) {
                        r4.setVisibility(View.VISIBLE);
                        r5.setVisibility(View.VISIBLE);
                        r6.setVisibility(View.VISIBLE);
                        r7.setVisibility(View.VISIBLE);
                        r4.setText(questionsArrayList.get(first).getChoices().get(3));
                        r5.setText(questionsArrayList.get(first).getChoices().get(4));
                        r6.setText(questionsArrayList.get(first).getChoices().get(5));
                        r7.setText(questionsArrayList.get(first).getChoices().get(6));
                    } else if (choiceSize == 8) {
                        r4.setVisibility(View.VISIBLE);
                        r5.setVisibility(View.VISIBLE);
                        r6.setVisibility(View.VISIBLE);
                        r7.setVisibility(View.VISIBLE);
                        r8.setVisibility(View.VISIBLE);
                        r4.setText(questionsArrayList.get(first).getChoices().get(3));
                        r5.setText(questionsArrayList.get(first).getChoices().get(4));
                        r6.setText(questionsArrayList.get(first).getChoices().get(5));
                        r7.setText(questionsArrayList.get(first).getChoices().get(6));
                        r8.setText(questionsArrayList.get(first).getChoices().get(7));
                    }

                    quest = (TextView) findViewById(R.id.questText);
                    quest.setText(questionsArrayList.get(first).getText());
                }
                else{
                    Intent stats = new Intent(Trivia.this,Stats.class);
                    stats.putExtra(rightanswers,count);
                    Log.d("count",""+count);
                    startActivity(stats);

                }
            }

        });


        findViewById(R.id.quitBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Trivia.this,MainActivity.class);
                startActivity(i);
            }
        });

        new CountDownTimer(120000, 1000) {

            public void onTick(long millisUntilFinished) {
                timer.setText("Time Left: " + millisUntilFinished / 1000 + " sec");
            }

            public void onFinish() {
                timer.setText("done!");
                Intent stats = new Intent(Trivia.this,Stats.class);
                stats.putExtra("count",count);
                Log.d("count",""+count);
                startActivity(stats);
            }
        }.start();
    }



}
