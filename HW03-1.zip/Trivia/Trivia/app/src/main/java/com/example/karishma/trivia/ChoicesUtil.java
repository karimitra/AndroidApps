package com.example.karishma.trivia;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by karishma on 9/22/2016.
 */
public class ChoicesUtil {

    public static class ChoicesJSONParser {
        static ArrayList<JSONArray> parseChoices(String in) throws JSONException {
            ArrayList<JSONArray> choicesList = new ArrayList<>();

            JSONObject root = new JSONObject(in);
            JSONArray questionsJSONArray = root.getJSONArray("questions");
            JSONObject choice = new JSONObject("choices");
            JSONArray choiceArray = choice.getJSONArray("choice");

            for(int i = 0;i<choiceArray.length();i++){
                choicesList.add(choiceArray);
            }
            return choicesList;
        }
    }
}
