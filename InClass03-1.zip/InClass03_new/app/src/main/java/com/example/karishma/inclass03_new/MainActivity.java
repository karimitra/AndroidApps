package com.example.karishma.inclass03_new;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Toast;

import com.example.karishma.inclass03_new.R;

public class MainActivity extends AppCompatActivity {

    final static String STUDENT_KEY = "STUDENT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setMax(100);

        Button button = (Button) findViewById(R.id.submitButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name, email;
                EditText nameField = (EditText) findViewById(R.id.name);
                if(!nameField.getText().toString().equals(""))
                {
                    name = nameField.getText().toString();
                }
                else
                {
                    name="";
                    Toast.makeText(MainActivity.this, "Enter Name", Toast.LENGTH_SHORT).show();
                }

                EditText emailField = (EditText) findViewById(R.id.email);
                if(!emailField.getText().toString().equals(""))
                {
                    email = emailField.getText().toString();
                }
                else
                {
                    email="";
                    Toast.makeText(MainActivity.this, "Enter Email", Toast.LENGTH_SHORT).show();
                }

                RadioGroup rg = (RadioGroup) findViewById(R.id.department);
                int selectedId = rg.getCheckedRadioButtonId();
                RadioButton department = (RadioButton) findViewById(selectedId);


                SeekBar mood = (SeekBar) findViewById(R.id.seekBar);
                int moodvalue = mood.getProgress();

                Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
                Student student = new Student(name, email, department.getText().toString(), moodvalue);
                intent.putExtra(STUDENT_KEY, student);

                if(!name.equals("") && !email.equals("")) {
                    startActivity(intent);
                }

            }
        });
    }
}
