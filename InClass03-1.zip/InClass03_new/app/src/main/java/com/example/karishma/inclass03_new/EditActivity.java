package com.example.karishma.inclass03_new;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by karishma on 9/6/2016.
 */
public class EditActivity extends Activity {
    final static String STUDENT_KEY = "STUDENT";
    Student student;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        final String deptIntent = getIntent().getStringExtra(DisplayActivity.DEPT_KEY);
        final String nameIntent = getIntent().getStringExtra(DisplayActivity.NAME_KEY);
        final String emailIntent = getIntent().getStringExtra(DisplayActivity.EMAIL_KEY);
        final String moodIntent = getIntent().getStringExtra(DisplayActivity.MOOD_KEY);

        Log.d("test", deptIntent + nameIntent + emailIntent + moodIntent);

        final EditText nameField = (EditText) findViewById(R.id.name);
        final EditText emailField = (EditText) findViewById(R.id.email);
        final RadioGroup rg = (RadioGroup) findViewById(R.id.department);
        RadioButton rdsis = (RadioButton) findViewById(R.id.dept_sis);
        RadioButton rdcs = (RadioButton) findViewById(R.id.dept_cs);
        RadioButton rdbio = (RadioButton) findViewById(R.id.dept_bio);
        RadioButton rdother = (RadioButton) findViewById(R.id.dept_others);

        TextView deptText = (TextView) findViewById(R.id.departmentLabel);
        final TextView moodText = (TextView) findViewById(R.id.currentMoodLabel);

        SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setMax(100);

        final SeekBar mood = (SeekBar) findViewById(R.id.seekBar);


        if (getIntent().getExtras() != null) {
            student = (Student) getIntent().getExtras().getSerializable(DisplayActivity.EDITSTUDENT_KEY);


            if (student != null) {
                String name, email;
                if (nameIntent != null) {

                    name = student.name;
                    nameField.setText(name);

                    emailField.setVisibility(TextView.INVISIBLE);
                    rg.setVisibility(RadioGroup.INVISIBLE);
                    seekBar.setVisibility(seekBar.INVISIBLE);
                    deptText.setVisibility(TextView.INVISIBLE);
                    moodText.setVisibility(TextView.INVISIBLE);

                    student.name = (nameField.getText().toString());
                } else if (emailIntent != null) {
                    email = student.emailId;
                    emailField.setText(email);

                    nameField.setVisibility(TextView.INVISIBLE);
                    rg.setVisibility(RadioGroup.INVISIBLE);
                    seekBar.setVisibility(seekBar.INVISIBLE);
                    deptText.setVisibility(TextView.INVISIBLE);
                    moodText.setVisibility(TextView.INVISIBLE);

                    student.setEmailId(emailField.getText().toString());
                } else if (deptIntent != null) {

                    int selectedId = rg.getCheckedRadioButtonId();
                    RadioButton department = (RadioButton) findViewById(selectedId);
                    String value = student.department;
                    if (value.equals("SIS")) {
                        rdsis.setChecked(true);
                        student.setDepartment("SIS");
                    } else if (value.equals("CS")) {

                        rdcs.setChecked(true);
                        student.setDepartment("CS");
                    } else if (value.equals("BIO")) {

                        rdbio.setChecked(true);
                        student.setDepartment("BIO");
                    } else {

                        rdother.setChecked(true);
                        student.setDepartment("OTHERS");
                    }

                    nameField.setVisibility(TextView.INVISIBLE);
                    emailField.setVisibility(TextView.INVISIBLE);
                    seekBar.setVisibility(seekBar.INVISIBLE);
                    moodText.setVisibility(TextView.INVISIBLE);


                } else if (moodIntent != null) {
                    int moodvalue = student.mood;
                    mood.setProgress(moodvalue);

                    nameField.setVisibility(TextView.INVISIBLE);
                    emailField.setVisibility(TextView.INVISIBLE);
                    rg.setVisibility(RadioGroup.INVISIBLE);
                    deptText.setVisibility(TextView.INVISIBLE);

                    student.setMood(mood.getProgress());
                }

                Button button = (Button) findViewById(R.id.submitButton);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent display = new Intent(EditActivity.this, DisplayActivity.class);
                        if(nameIntent!=null)
                        {
                            student.setName(nameField.getText().toString());
                        }
                        else if (emailIntent != null)
                        {
                            student.setEmailId(emailField.getText().toString());
                        }
                        else if (moodIntent!=null)
                        {
                            student.setMood(mood.getProgress());
                        }
                        else if (deptIntent!=null)
                        {
                            int selectedId = rg.getCheckedRadioButtonId();
                            RadioButton department = (RadioButton) findViewById(selectedId);
                            student.setDepartment(department.getText().toString());
                        }
                        display.putExtra(STUDENT_KEY, student);

                        startActivity(display);
                    }
                });
            }

        }
    }
}
   // Intent intent = new Intent(EditActivity.this, DisplayActivity.class);
   // Student student = new Student(name, email, department.getText().toString(), moodvalue);
//intent.putExtra(STUDENT_KEY, student);


