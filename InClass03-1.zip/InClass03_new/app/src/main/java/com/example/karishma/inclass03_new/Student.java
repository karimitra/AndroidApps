package com.example.karishma.inclass03_new;

import java.io.Serializable;

/**
 * Created by rimpl on 9/6/2016.
 */
public class Student implements Serializable {

    public String name;
    public String emailId;
    public String department;
    public String accState;
    public int mood;

    public Student(String name, String emailId, String department, int mood) {
        this.setName(name);
        this.setEmailId(emailId);
        this.setDepartment(department);
        this.setMood(mood);
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + getName() + '\'' +
                ", emailId='" + getEmailId() + '\'' +
                ", department='" + getDepartment() + '\'' +
                ", mood=" + getMood() +
                '}';
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setAccState(String accState) {
        this.accState = accState;
    }

    public void setMood(int mood) {
        this.mood = mood;
    }

    public String getName() {
        return name;
    }

    public String getEmailId() {
        return emailId;
    }

    public String getDepartment() {
        return department;
    }

    public String getAccState() {
        return accState;
    }

    public int getMood() {
        return mood;
    }
}
