package com.example.karishma.inclass03_new;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

//import com.google.android.gms.appindexing.Action;
//import com.google.android.gms.appindexing.AppIndex;
//import com.google.android.gms.common.api.GoogleApiClient;

public class DisplayActivity extends AppCompatActivity {

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    TextView studentInfo;
    TextView name;
    TextView email;
    TextView department;
    TextView mood;
    ImageButton editButtonname;
    ImageButton editButtonemail;
    ImageButton editButtonDept;
    ImageButton editButtonMood;
    final static String EDITSTUDENT_KEY = "EDITSTUDENT";
    final static String DEPT_KEY = "DEPT";
    final static String MOOD_KEY = "MOOD";
    final static String EMAIL_KEY = "EMAIL";
    final static String NAME_KEY = "NAME";

    Student student;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_display);

        if (getIntent().getExtras() != null) {
            student = (Student) getIntent().getExtras().getSerializable(MainActivity.STUDENT_KEY);

            if (student != null) {
                RelativeLayout relativeLayout = new RelativeLayout(this);
                relativeLayout.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                setContentView(relativeLayout);

                studentInfo = new TextView(this);
                studentInfo.setText("Student Information");
                studentInfo.setGravity(Gravity.CENTER);
                studentInfo.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                relativeLayout.addView(studentInfo);
                studentInfo.setId(100);

                name = new TextView(this);
                name.setText("Name: " + student.name);
                RelativeLayout.LayoutParams nameLayoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                nameLayoutParams.addRule(RelativeLayout.BELOW, studentInfo.getId());
                name.setLayoutParams(nameLayoutParams);
                relativeLayout.addView(name);
                name.setId(200);

                email = new TextView(this);
                email.setText("Email: " + student.emailId);
                RelativeLayout.LayoutParams emailLayoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                emailLayoutParams.addRule(RelativeLayout.BELOW, name.getId());
                email.setLayoutParams(emailLayoutParams);
                relativeLayout.addView(email);
                email.setId(300);

                department = new TextView(this);
                department.setText("Department: " + student.department);
                Log.d("rd",student.department);
                RelativeLayout.LayoutParams departmentLayoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                departmentLayoutParams.addRule(RelativeLayout.BELOW, email.getId());
                department.setLayoutParams(departmentLayoutParams);
                relativeLayout.addView(department);
                department.setId(400);

                mood = new TextView(this);
                mood.setText("Mood: " + student.mood + " % Positive");
                RelativeLayout.LayoutParams moodLayoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                moodLayoutParams.addRule(RelativeLayout.BELOW, department.getId());
                mood.setLayoutParams(moodLayoutParams);
                relativeLayout.addView(mood);
                mood.setId(500);

                editButtonname = new ImageButton(this);
                editButtonname.setBackgroundResource(R.drawable.ic_action_edit);
                RelativeLayout.LayoutParams editbuttonnameLayoutParams = new RelativeLayout.LayoutParams(50,50);
                editbuttonnameLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,name.getId());
                editbuttonnameLayoutParams.addRule(RelativeLayout.BELOW,studentInfo.getId());
                editButtonname.setLayoutParams(editbuttonnameLayoutParams);
                relativeLayout.addView(editButtonname);
                editButtonname.setId(600);

                editButtonemail = new ImageButton(this);
                editButtonemail.setBackgroundResource(R.drawable.ic_action_edit);
                RelativeLayout.LayoutParams editbuttonLayoutParams = new RelativeLayout.LayoutParams(50,50);
                editbuttonLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,email.getId());
                editbuttonLayoutParams.addRule(RelativeLayout.BELOW,editButtonname.getId());
                editButtonemail.setLayoutParams(editbuttonLayoutParams);
                relativeLayout.addView(editButtonemail);
                editButtonemail.setId(700);

                editButtonDept = new ImageButton(this);
                editButtonDept.setBackgroundResource(R.drawable.ic_action_edit);
                RelativeLayout.LayoutParams editbuttonDeptLayoutParams = new RelativeLayout.LayoutParams(50,50);
                editbuttonDeptLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,department.getId());
                editbuttonDeptLayoutParams.addRule(RelativeLayout.BELOW,editButtonemail.getId());
                editButtonDept.setLayoutParams(editbuttonDeptLayoutParams);
                relativeLayout.addView(editButtonDept);
                editButtonDept.setId(800);

                editButtonMood = new ImageButton(this);
                editButtonMood.setBackgroundResource(R.drawable.ic_action_edit);
                RelativeLayout.LayoutParams editbuttonMoodLayoutParams = new RelativeLayout.LayoutParams(50,50);
                editbuttonMoodLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT,mood.getId());
                editbuttonMoodLayoutParams.addRule(RelativeLayout.BELOW,editButtonDept.getId());
                editButtonMood.setLayoutParams(editbuttonMoodLayoutParams);
                relativeLayout.addView(editButtonMood);
                editButtonMood.setId(900);
            }
        }
        editButtonname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editName = new Intent(DisplayActivity.this,EditActivity.class);
                editName.putExtra(NAME_KEY,"name");
                editName.putExtra(EDITSTUDENT_KEY, student);
                startActivity(editName);
            }
        });

        editButtonemail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editEmail = new Intent(DisplayActivity.this,EditActivity.class);
                editEmail.putExtra(EMAIL_KEY,"email");
                editEmail.putExtra(EDITSTUDENT_KEY, student);
                startActivity(editEmail);
            }
        });
        editButtonDept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editDept = new Intent(DisplayActivity.this,EditActivity.class);
                editDept.putExtra(DEPT_KEY,"dept");
                editDept.putExtra(EDITSTUDENT_KEY, student);
                startActivity(editDept);
            }
        });

        editButtonMood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editMood = new Intent(DisplayActivity.this,EditActivity.class);
                editMood.putExtra(MOOD_KEY,"mood");
                editMood.putExtra(EDITSTUDENT_KEY, student);
                startActivity(editMood);
            }
        });


    }
}