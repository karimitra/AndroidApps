package com.example.karishma.expenseapp;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AddExpense extends Activity {

    final static String EXPENSE_KEY = "EXPENSES";
    final static String EXPENSE_LIST_KEY ="EXPENSE_LIST";
    final static String addExpense="ADD_EXPENSE";
    int mYear, mMonth, mDay;
    ArrayList<Expenses> expenseList ;

    String imageUri;

    ImageView viewImage;

    @TargetApi(Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        viewImage = (ImageView) findViewById(R.id.imageView2);

        expenseList = getIntent().getParcelableArrayListExtra(MainActivity.EXPENSE_LIST_KEY);
        Spinner staticSpinner = (Spinner) findViewById(R.id.static_spinner);

        // Create an ArrayAdapter using the string array and a default spinner
        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(this, R.array.category,
                        android.R.layout.simple_spinner_item);

        // Specify the layout to use when the list of choices appears
        staticAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        staticSpinner.setAdapter(staticAdapter);

        final EditText datePicker = (EditText) findViewById(R.id.datePicker);

        if(expenseList == null){
            expenseList = new ArrayList<Expenses>();
        }
        ImageButton imgBtn = (ImageButton) findViewById(R.id.calenderImageButton);
        imgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mcurrentDate=Calendar.getInstance();
                mYear=mcurrentDate.get(Calendar.YEAR);
                mMonth=mcurrentDate.get(Calendar.MONTH);
                mDay=mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker=new DatePickerDialog(AddExpense.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                    datePicker.setText("" + selectedmonth + "-" + selectedday + "-" + selectedyear);
                    }
                },mYear, mMonth, mDay);
                mDatePicker.setTitle("Select date");
                mDatePicker.show();
            }
        });

        findViewById(R.id.imageButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });

        Button addExpenses_btn = (Button) findViewById(R.id.editExpenseBtn);
        addExpenses_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String expensesName,category, date, image;
                String amount;
                EditText nameField = (EditText) findViewById(R.id.expenseNameEditText);
                if(!nameField.getText().toString().equals(""))
                {
                    expensesName = nameField.getText().toString();
                }
                else
                {
                    expensesName="";
                    Toast.makeText(AddExpense.this, "Enter Expenses Name", Toast.LENGTH_SHORT).show();
                }

                Spinner categoryField = (Spinner) findViewById(R.id.static_spinner);
                if(!categoryField.getSelectedItem().toString().equals("Category"))
                {
                    category = categoryField.getSelectedItem().toString();
                }
                else {
                    category = "category";
                    Toast.makeText(AddExpense.this, "Select Category", Toast.LENGTH_SHORT).show();
                }

                EditText amountField = (EditText) findViewById(R.id.AmountEditText);
                if(!amountField.getText().toString().equals("") ){

                    amount = amountField.getText().toString();
                }
                else{
                    amount = "";
                    Toast.makeText(AddExpense.this, "Enter Amount", Toast.LENGTH_SHORT).show();
                }

                EditText dateField = (EditText) findViewById(R.id.datePicker);
                if(!dateField.getText().toString().equals("")){
                    date = dateField.getText().toString();
                }
                else{
                    date = "";
                    Toast.makeText(AddExpense.this, "Select a Date", Toast.LENGTH_SHORT).show();
                }

                Intent main = new Intent (AddExpense.this, MainActivity.class);
                Expenses expense = new Expenses(expensesName, category, amount, date, imageUri);
                expenseList.add(expense);
                Toast.makeText(AddExpense.this,"expenseList" + expenseList.get(expenseList.size()-1).amount, Toast.LENGTH_LONG).show();

              //  toShowExpenses.putExtra(EXPENSE_LIST_KEY, (Serializable) expenseList);
               //main.putExtra(EXPENSE_LIST_KEY,(ArrayList) expenseList);
                main.putParcelableArrayListExtra(EXPENSE_LIST_KEY,expenseList);

                Log.d("Demo","Add List: " + expenseList);

                main.putExtra(addExpense,"ADD");
                startActivity(main);
                    }
        });
    }

    private void selectImage() {

        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };

        AlertDialog.Builder builder = new AlertDialog.Builder(AddExpense.this);
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo"))
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                    startActivityForResult(intent, 1);
                }
                else if (options[item].equals("Choose from Gallery"))
                {
                    Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 2);

                }
                else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                File f = new File(Environment.getExternalStorageDirectory().toString());
                for (File temp : f.listFiles()) {
                    if (temp.getName().equals("temp.jpg")) {
                        f = temp;
                        break;
                    }
                }
                try {
                    Bitmap bitmap;
                    BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();

                    bitmap = BitmapFactory.decodeFile(f.getAbsolutePath(),
                            bitmapOptions);

                    viewImage.setImageBitmap(bitmap);
                    String path = android.os.Environment
                            .getExternalStorageDirectory()
                            + File.separator
                            + "Phoenix" + File.separator + "default";
                    f.delete();
                    OutputStream outFile = null;
                    File file = new File(path, String.valueOf(System.currentTimeMillis()) + ".jpg");
                    try {
                        outFile = new FileOutputStream(file);
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outFile);
                        outFile.flush();
                        outFile.close();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (requestCode == 2) {

                Uri selectedImage = data.getData();
                Log.d("demo","URI is "+selectedImage);
                imageUri=selectedImage.toString();
                String[] filePath = { MediaStore.Images.Media.DATA };
                Cursor c = getContentResolver().query(selectedImage,filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                String picturePath = c.getString(columnIndex);
                c.close();
                Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                // Log.w("path of image from gallery.....****.....", picturePath+"");
                viewImage.setImageBitmap(thumbnail);
            }
        }
    }
}
