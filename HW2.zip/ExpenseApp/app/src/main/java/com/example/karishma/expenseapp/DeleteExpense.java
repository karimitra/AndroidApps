package com.example.karishma.expenseapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DeleteExpense extends AppCompatActivity {

    final static String EXPENSE_LIST_KEY ="EXPENSE_LIST";
    final static String deleteExpense="DELETE_EXPENSE";
    ArrayList<Expenses> expenseList;
    String[] expenses;
    EditText expenseName, amount, date;
    Button deleteExpensebtn;
    Expenses expenseToDelete;
    Spinner staticSpinner;
    ImageView deleteImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_expense);

        deleteImage=(ImageView)findViewById(R.id.imageView4);
        staticSpinner  = (Spinner) findViewById(R.id.static_spinner);

        // Create an ArrayAdapter using the string array and a default spinner
        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(this, R.array.category,
                        android.R.layout.simple_spinner_item);

        // Specify the layout to use when the list of choices appears
        staticAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        staticSpinner.setAdapter(staticAdapter);

        expenseName=(EditText)findViewById(R.id.expenseNameEditText);
        amount=(EditText) findViewById(R.id.AmountEditText);
        date=(EditText) findViewById(R.id.datePicker);
        deleteExpensebtn =(Button) findViewById(R.id.deleteExpensebtn);

        if(getIntent().getExtras()!=null) {
                expenseList=getIntent().getParcelableArrayListExtra(MainActivity.EXPENSE_LIST_KEY);
                Log.d("demo","Delete ExpenseList"+expenseList.get(0));
        }

        findViewById(R.id.selectExpenseBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(expenseList.size()!=0)
                {
                    expenses= new String[expenseList.size()];
                    for(int i=0; i<expenseList.size();i++)
                    {
                        expenses[i]=expenseList.get(i).expenseName;
                    }
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(DeleteExpense.this);
                builder.setTitle("Make your selection");
                builder.setItems(expenses, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        // Do something with the selection
                        expenseToDelete =expenseList.get(item);
                        expenseName.setText(expenseList.get(item).expenseName);
                        amount.setText((expenseList.get(item).amount));
                        date.setText(expenseList.get(item).date);

                        for(int i=0;i<staticSpinner.getCount();i++)
                        {
                            if(staticSpinner.getItemAtPosition(i).toString().equalsIgnoreCase(expenseList.get(item).category))
                            {
                                staticSpinner.setSelection(i);
                                break;
                            }
                        }
                        String image = expenseList.get(item).image;
                        Uri imageUri = Uri.parse(image);

                        String[] filePath = { MediaStore.Images.Media.DATA };
                        Cursor c = getContentResolver().query(imageUri,filePath, null, null, null);
                        c.moveToFirst();
                        int columnIndex = c.getColumnIndex(filePath[0]);
                        String picturePath = c.getString(columnIndex);
                        c.close();
                        Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                        // Log.w("path of image from gallery.....****.....", picturePath+"");
                        deleteImage.setImageBitmap(thumbnail);
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });
        final Intent main = new Intent(DeleteExpense.this,MainActivity.class);
        deleteExpensebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                for(int i=0;i<expenseList.size();i++)
                {
                    if(expenseList.get(i).expenseName.equalsIgnoreCase(expenseToDelete.expenseName))
                    {
                        expenseList.remove(i);
                    }

                }
                main.putParcelableArrayListExtra(EXPENSE_LIST_KEY, expenseList);
                main.putExtra(deleteExpense,"Delete Expense");
                startActivity(main);
            }
        });

        findViewById(R.id.cancelButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                main.putParcelableArrayListExtra(EXPENSE_LIST_KEY, expenseList);
                main.putExtra(deleteExpense,"Delete Expense");
                startActivity(main);
            }
        });
    }
}

