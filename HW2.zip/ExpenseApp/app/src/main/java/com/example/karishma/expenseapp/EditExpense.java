package com.example.karishma.expenseapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class EditExpense extends AppCompatActivity {

    final static String EXPENSE_LIST_KEY ="EXPENSE_LIST";
    final static String editExpense="EDIT_EXPENSE";
    ArrayList<Expenses> expenseList;
    String[] expenses;
    EditText expenseName, amount, date;
    Button editExpensebtn;
    Expenses expenseToEdit;
    ImageView editImage;
    Spinner staticSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_expense);

        editImage=(ImageView)findViewById(R.id.imageView3);
        staticSpinner=(Spinner)findViewById(R.id.static_spinner);
        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(this, R.array.category,
                        android.R.layout.simple_spinner_item);

        // Specify the layout to use when the list of choices appears
        staticAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        staticSpinner.setAdapter(staticAdapter);

        expenseName=(EditText)findViewById(R.id.expenseNameEditText);
        amount=(EditText) findViewById(R.id.AmountEditText);
        date=(EditText) findViewById(R.id.datePicker);

        editExpensebtn =(Button) findViewById(R.id.editExpenseBtn);

        if(getIntent().getExtras()!=null) {

                expenseList=getIntent().getParcelableArrayListExtra(MainActivity.EXPENSE_LIST_KEY);
                Log.d("demo","ExpenseList Size"+expenseList.size());
        }

        findViewById(R.id.selectExpenseBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(expenseList.size()!=0)
                {
                expenses= new String[expenseList.size()];
                    for(int i=0; i<expenseList.size();i++)
                    {
                        expenses[i]=expenseList.get(i).expenseName;Log.d("hi","name: "+ expenses[i]);

                    }
                }


                AlertDialog.Builder builder = new AlertDialog.Builder(EditExpense.this);
                builder.setTitle("Make your selection");
                builder.setItems(expenses, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        // Do something with the selection
                        expenseToEdit=expenseList.get(item);
                    expenseName.setText(expenseList.get(item).expenseName);
                        Log.d("name is ", expenseList.get(item).expenseName);
                        Log.d("amount is ", expenseList.get(item).amount);
                        amount.setText((expenseList.get(item).amount));
                        date.setText(expenseList.get(item).date);

                        for(int i=0;i<staticSpinner.getCount();i++)
                        {
                            if(staticSpinner.getItemAtPosition(i).toString().equalsIgnoreCase(expenseList.get(item).category))
                            {
                                staticSpinner.setSelection(i);
                                break;
                            }
                        }
                        String image = expenseList.get(item).image;
                        Uri imageUri = Uri.parse(image);

                        String[] filePath = { MediaStore.Images.Media.DATA };
                        Cursor c = getContentResolver().query(imageUri,filePath, null, null, null);
                        c.moveToFirst();
                        int columnIndex = c.getColumnIndex(filePath[0]);
                        String picturePath = c.getString(columnIndex);
                        c.close();
                        Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                        // Log.w("path of image from gallery.....****.....", picturePath+"");
                        editImage.setImageBitmap(thumbnail);
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });
       final Intent main = new Intent(EditExpense.this,MainActivity.class);
        editExpensebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                for(int i=0;i<expenseList.size();i++)
                {
                    if(expenseList.get(i).expenseName.equalsIgnoreCase(expenseToEdit.expenseName))
                    {
                        expenseList.get(i).setExpenseName(expenseName.getText().toString());
                        expenseList.get(i).setCategory(staticSpinner.getSelectedItem().toString());
                        expenseList.get(i).setAmount(amount.getText().toString());
                        expenseList.get(i).setDate(date.getText().toString());
                    }

                }
                main.putParcelableArrayListExtra(EXPENSE_LIST_KEY,expenseList);
                main.putExtra(editExpense,"Edit Expense");
                startActivity(main);
            }
        });

        findViewById(R.id.cancelButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                main.putParcelableArrayListExtra(EXPENSE_LIST_KEY,expenseList);
                main.putExtra(editExpense,"Edit Expense");
                startActivity(main);
            }
        });
    }
}
