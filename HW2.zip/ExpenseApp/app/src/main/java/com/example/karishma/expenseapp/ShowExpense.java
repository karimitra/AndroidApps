package com.example.karishma.expenseapp;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ShowExpense extends AppCompatActivity {

    int item = 0;
    TextView name;
    TextView category;
    TextView amount;
    TextView date;
    ImageView showImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_expense);
        final ArrayList<Expenses> expensesList;
        name = (TextView) findViewById(R.id.nameExpense);
        category = (TextView) findViewById(R.id.categoryExpense);
        amount = (TextView) findViewById(R.id.amountExpense);
        date = (TextView) findViewById(R.id.dateExpense);
        showImage=(ImageView)findViewById(R.id.imageView);

        final Button finish = (Button) findViewById(R.id.finish);
        Button first = (Button) findViewById(R.id.first);
        Button previous = (Button) findViewById(R.id.previous);
        Button next = (Button) findViewById(R.id.next);
        Button last = (Button) findViewById(R.id.last);

        if (getIntent().getExtras() != null) {
            expensesList = getIntent().getParcelableArrayListExtra(MainActivity.EXPENSE_LIST_KEY);
            Log.d("size","size: " + expensesList.size());
            name.setText(expensesList.get(item).expenseName);
            category.setText(expensesList.get(item).category);
            amount.setText(expensesList.get(item).amount);
            date.setText(expensesList.get(item).date);

            String image = expensesList.get(item).image;
            Uri imageUri = Uri.parse(image);

            String[] filePath = { MediaStore.Images.Media.DATA };
            Cursor c = getContentResolver().query(imageUri,filePath, null, null, null);
            c.moveToFirst();
            int columnIndex = c.getColumnIndex(filePath[0]);
            String picturePath = c.getString(columnIndex);
            c.close();
            Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
            // Log.w("path of image from gallery.....****.....", picturePath+"");
            showImage.setImageBitmap(thumbnail);

            finish.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });

            first.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(expensesList.size()==1)
                    {
                        Toast.makeText(ShowExpense.this, "No more expenses to show", Toast.LENGTH_SHORT).show();
                    }
                    else if (item == 0 )
                    {
                        Toast.makeText(ShowExpense.this, "No more expenses to show", Toast.LENGTH_SHORT).show();
                    }
                    else if(item > 0)
                    {
                        item  = 0;
                        name.setText(expensesList.get(item).expenseName);
                        category.setText(expensesList.get(item).category);
                        amount.setText(expensesList.get(item).amount);
                        date.setText(expensesList.get(item).date);

                        String image = expensesList.get(item).image;
                        Uri imageUri = Uri.parse(image);

                        String[] filePath = { MediaStore.Images.Media.DATA };
                        Cursor c = getContentResolver().query(imageUri,filePath, null, null, null);
                        c.moveToFirst();
                        int columnIndex = c.getColumnIndex(filePath[0]);
                        String picturePath = c.getString(columnIndex);
                        c.close();
                        Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                        // Log.w("path of image from gallery.....****.....", picturePath+"");
                        showImage.setImageBitmap(thumbnail);
                    }
                }
            });

            previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(expensesList.size()==1)
                    {
                        Toast.makeText(ShowExpense.this, "No more expenses to show", Toast.LENGTH_SHORT).show();
                    }
                    else if (item == 0 )
                    {
                        Toast.makeText(ShowExpense.this, "No more expenses to show", Toast.LENGTH_SHORT).show();
                    }
                    else if(item > 0)
                    {
                        item  = item - 1;
                        name.setText(expensesList.get(item).expenseName);
                        category.setText(expensesList.get(item).category);
                        amount.setText(expensesList.get(item).amount);
                        date.setText(expensesList.get(item).date);

                        String image = expensesList.get(item).image;
                        Uri imageUri = Uri.parse(image);

                        String[] filePath = { MediaStore.Images.Media.DATA };
                        Cursor c = getContentResolver().query(imageUri,filePath, null, null, null);
                        c.moveToFirst();
                        int columnIndex = c.getColumnIndex(filePath[0]);
                        String picturePath = c.getString(columnIndex);
                        c.close();
                        Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                        // Log.w("path of image from gallery.....****.....", picturePath+"");
                        showImage.setImageBitmap(thumbnail);
                    }
                }
            });

            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(expensesList.size()==1)
                    {
                        Toast.makeText(ShowExpense.this, "No more expenses to show", Toast.LENGTH_SHORT).show();
                    }
                    else if (item == expensesList.size())
                    {
                        Toast.makeText(ShowExpense.this, "No more expenses to show", Toast.LENGTH_SHORT).show();
                    }
                    else if(item < expensesList.size())
                    {
                        item  = item + 1;
                        name.setText(expensesList.get(item).expenseName);
                        category.setText(expensesList.get(item).category);
                        amount.setText(expensesList.get(item).amount);
                        date.setText(expensesList.get(item).date);

                        String image = expensesList.get(item).image;
                        Uri imageUri = Uri.parse(image);

                        String[] filePath = { MediaStore.Images.Media.DATA };
                        Cursor c = getContentResolver().query(imageUri,filePath, null, null, null);
                        c.moveToFirst();
                        int columnIndex = c.getColumnIndex(filePath[0]);
                        String picturePath = c.getString(columnIndex);
                        c.close();
                        Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                        // Log.w("path of image from gallery.....****.....", picturePath+"");
                        showImage.setImageBitmap(thumbnail);
                    }
                }
            });

            last.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(expensesList.size()==1)
                    {
                        Toast.makeText(ShowExpense.this, "No more expenses to show", Toast.LENGTH_SHORT).show();
                    }
                    else if (item == expensesList.size() )
                    {
                        Toast.makeText(ShowExpense.this, "No more expenses to show", Toast.LENGTH_SHORT).show();
                    }
                    else if(item < expensesList.size())
                    {
                        item  = expensesList.size()-1;
                        name.setText(expensesList.get(item).expenseName);
                        category.setText(expensesList.get(item).category);
                        amount.setText(expensesList.get(item).amount);
                        date.setText(expensesList.get(item).date);

                        String image = expensesList.get(item).image;
                        Uri imageUri = Uri.parse(image);

                        String[] filePath = { MediaStore.Images.Media.DATA };
                        Cursor c = getContentResolver().query(imageUri,filePath, null, null, null);
                        c.moveToFirst();
                        int columnIndex = c.getColumnIndex(filePath[0]);
                        String picturePath = c.getString(columnIndex);
                        c.close();
                        Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                        // Log.w("path of image from gallery.....****.....", picturePath+"");
                        showImage.setImageBitmap(thumbnail);
                    }

                }
            });
        }
    }
}
