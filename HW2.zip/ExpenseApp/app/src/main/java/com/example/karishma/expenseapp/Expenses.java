package com.example.karishma.expenseapp;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by karishma on 9/12/2016.
 */
public class Expenses implements Parcelable{
    public String expenseName;
    public String category;
    public String amount;
    public String date;
    public String image;

    public Expenses(String expenseName, String category, String amount, String date, String image) {
        this.expenseName = expenseName;
        this.category = category;
        this.amount = amount;
        this.date = date;
        this.image = image;
    }

    protected Expenses(Parcel in) {
        expenseName = in.readString();
        category = in.readString();
        amount = in.readString();
        date = in.readString();
        image = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(expenseName);
        dest.writeString(category);
        dest.writeString(amount);
        dest.writeString(date);
        dest.writeString(image);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Expenses> CREATOR = new Creator<Expenses>() {
        @Override
        public Expenses createFromParcel(Parcel in) {
            return new Expenses(in);
        }

        @Override
        public Expenses[] newArray(int size) {
            return new Expenses[size];
        }
    };

    @Override
    public String toString() {
        return "Expenses{" +
                "expenseName='" + expenseName + '\'' +
                ", category='" + category + '\'' +
                ", amount=" + amount +
                ", date='" + date + '\'' +
                ", image='" + image + '\'' +
                '}';
    }

    public String getExpenseName() {
        return expenseName;
    }

    public void setExpenseName(String expenseName) {
        this.expenseName = expenseName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


}
