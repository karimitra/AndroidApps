package com.example.karishma.expenseapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    final static String EXPENSE_LIST_KEY ="EXPENSE_LIST";
    ArrayList<Expenses> expensesList = new ArrayList<Expenses>();

   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       final String addExpense =getIntent().getStringExtra(AddExpense.addExpense);
       final String editExpense =getIntent().getStringExtra(EditExpense.editExpense);
       final String deleteExpense =getIntent().getStringExtra(DeleteExpense.deleteExpense);

       final Button addExpenseBtn = (Button) findViewById(R.id.addExpense);
       Button editExpenseBtn = (Button) findViewById(R.id.editExpense);
       Button deleteExpenseBtn = (Button) findViewById(R.id.deleteExpense);
       Button showExpenseBtn = (Button) findViewById(R.id.showExpenses);

       Log.d("demo","Add: " + addExpense + " Edit: " + editExpense+" Delete: " + deleteExpense);
       Intent i = this.getIntent();

        if(getIntent().getExtras()!=null)
        {
         if(addExpense!=null)
         {
             expensesList=i.getParcelableArrayListExtra(AddExpense.EXPENSE_LIST_KEY);
             Log.d("demo","Main List "+expensesList.get(0));
         }
            else if(editExpense!=null)
         {
             expensesList=getIntent().getParcelableArrayListExtra(EditExpense.EXPENSE_LIST_KEY);
         }
         else if(deleteExpense!=null)
         {
             expensesList=getIntent().getParcelableArrayListExtra(DeleteExpense.EXPENSE_LIST_KEY);
         }

        }

       addExpenseBtn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent addExpenseIntent = new Intent(MainActivity.this, AddExpense.class);
               addExpenseIntent.putExtra(EXPENSE_LIST_KEY, (ArrayList) expensesList);
               startActivity(addExpenseIntent);
           }
       });
       if(expensesList.size()!=0) {

           editExpenseBtn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Intent editExpenseIntent = new Intent(MainActivity.this, EditExpense.class);
                   editExpenseIntent.putParcelableArrayListExtra(EXPENSE_LIST_KEY, expensesList);
                   startActivity(editExpenseIntent);
               }
           });

           deleteExpenseBtn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Intent deleteExpenseIntent = new Intent(MainActivity.this, DeleteExpense.class);
                   deleteExpenseIntent.putParcelableArrayListExtra(EXPENSE_LIST_KEY, expensesList);
                   startActivity(deleteExpenseIntent);
               }
           });

           showExpenseBtn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Intent showExpenseIntent = new Intent(MainActivity.this, ShowExpense.class);
                   showExpenseIntent.putParcelableArrayListExtra(EXPENSE_LIST_KEY, expensesList);
                   startActivity(showExpenseIntent);
               }
           });

       }
       else
       {
           editExpenseBtn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Toast.makeText(MainActivity.this, "You do not have any expenses..Please add one!", Toast.LENGTH_SHORT).show();
               }
           });

           deleteExpenseBtn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Toast.makeText(MainActivity.this, "You do not have any expenses..Please add one!", Toast.LENGTH_SHORT).show();
               }
           });

           showExpenseBtn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Toast.makeText(MainActivity.this, "You do not have any expenses..Please add one!", Toast.LENGTH_SHORT).show();
               }
           });
       }

       final Button finish = (Button) findViewById(R.id.finish);

       finish.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Toast.makeText(MainActivity.this, "Thank You for using our app!", Toast.LENGTH_SHORT).show();
               finish();
               System.exit(0);
           }
       });
    }
    }



